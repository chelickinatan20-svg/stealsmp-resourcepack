STEALSMP — POLACZONA PACZKA UNIWERSALNA

Kompatybilnosc: Minecraft Java 1.20 - 1.21.11

Zawartosc:
- logo STEALSMP na scoreboardzie (znak U+E001)
- fioletowy STEAL SET w stylu podgladu
- STEAL SWORD w stylu przeslanego obrazka
- STEAL PICKAXE w tym samym fioletowym stylu

Dopasowanie do skryptow v3:
- 9101 = STEAL HELMET
- 9102 = STEAL CHESTPLATE
- 9103 = STEAL LEGGINGS
- 9104 = STEAL BOOTS
- 9105 = STEAL SWORD
- 9106 = STEAL PICKAXE

Zalozona zbroja:
- 1.20 - 1.21.1: paczka podmienia wyglad netheritowej zbroi na fioletowy (to jedyny sposob dla tych wersji)
- 1.21.2+: skrypt korzysta z equipped model key: stealsmp:steal

Scoreboard:
- znak do wklejenia w tytul: 
- przyklad: title: ""

Instalacja:
1. Wrzuć ZIP bez rozpakowywania do .minecraft/resourcepacks
2. Wlacz paczke
3. Uzyj F3+T


POPRAWKA:
- usuniete tlo z tekstury miecza
- wyglad zalozonej zbroi zostal dodatkowo przesuniety w bardziej fioletowy netheryt
